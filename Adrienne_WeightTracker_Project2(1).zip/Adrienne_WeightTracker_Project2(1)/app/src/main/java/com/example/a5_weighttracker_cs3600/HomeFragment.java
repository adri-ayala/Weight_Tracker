package com.example.a5_weighttracker_cs3600;

import android.database.Cursor;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.content.Context;
import android.content.SharedPreferences;


public class HomeFragment extends Fragment {
    private static final String CHANNEL_ID = "goal_notifications";

    EditText editDate, editWeight;
    Button btnAdd;
    RecyclerView recyclerView;
    TextView textEmptyMessage;

    DatabaseHelper db;
    int userId;

    ArrayList<WeightItem> weightList;
    WeightAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);

        userId = getActivity().getIntent().getIntExtra("user_id", -1);
        db = new DatabaseHelper(getContext());

        editDate = view.findViewById(R.id.editDate);
        editWeight = view.findViewById(R.id.editWeight);
        btnAdd = view.findViewById(R.id.btnAdd);
        recyclerView = view.findViewById(R.id.recyclerWeights);
        textEmptyMessage = view.findViewById(R.id.textEmptyGridMessage);

        weightList = new ArrayList<>();
        adapter = new WeightAdapter(getContext(), weightList, this::loadWeights);

        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        recyclerView.setAdapter(adapter);

        loadWeights();
// adds to database
        btnAdd.setOnClickListener(v -> {
            String date = editDate.getText().toString().trim();
            String weightStr = editWeight.getText().toString().trim();

            if (date.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(getContext(), "Please enter date and weight.", Toast.LENGTH_SHORT).show();
                return;
            }

            double weight = Double.parseDouble(weightStr);

            if (db.addWeight(date, weight, userId)) {
                Toast.makeText(getContext(), "Entry added!", Toast.LENGTH_SHORT).show();
                editDate.setText("");
                editWeight.setText("");
                loadWeights();
                checkGoalAndNotify();
            }
        });

        return view;
    }
// displays weight database
    private void loadWeights() {
        weightList.clear();
        Cursor cursor = db.getWeights(userId);

        if (cursor.getCount() == 0) {
            textEmptyMessage.setVisibility(View.VISIBLE);
        } else {
            textEmptyMessage.setVisibility(View.GONE);
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
                weightList.add(new WeightItem(id, date, weight));
            }
        }
        adapter.notifyDataSetChanged();
    }

    // checks if your entered weight matches your goal, if so then sends a notification
    private void checkGoalAndNotify() {

        SharedPreferences prefs = requireContext()
                .getSharedPreferences("GoalPrefs", Context.MODE_PRIVATE);
        boolean notifyEnabled = prefs.getBoolean("notifications_enabled", false);

        Toast.makeText(getContext(), "Notify Enabled = " + notifyEnabled, Toast.LENGTH_SHORT).show();
        if (!notifyEnabled) return;

        Double goal = db.getGoal(userId);
        Toast.makeText(getContext(), "Goal = " + goal, Toast.LENGTH_SHORT).show();
        if (goal == null) return;

        Cursor cursor = db.getWeights(userId);
        if (cursor.getCount() == 0) {
            Toast.makeText(getContext(), "No weights found", Toast.LENGTH_SHORT).show();
            return;
        }
        cursor.moveToLast();
        double lastWeight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
        cursor.close();

        Toast.makeText(getContext(), "Last Weight = " + lastWeight, Toast.LENGTH_SHORT).show();

        if (lastWeight <= goal) {
            Toast.makeText(getContext(), "Goal Reached!!!", Toast.LENGTH_SHORT).show();
            sendGoalNotification();
        } else {
            Toast.makeText(getContext(), "No notification — weight > goal", Toast.LENGTH_SHORT).show();
        }
    }



    private void sendGoalNotification() {
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(requireContext(), CHANNEL_ID)
                        .setSmallIcon(android.R.drawable.star_on)
                        .setContentTitle("Goal Reached!")
                        .setContentText("You hit your weight goal today!")
                        .setPriority(NotificationCompat.PRIORITY_HIGH);

        NotificationManagerCompat manager = NotificationManagerCompat.from(requireContext());
        manager.notify(1, builder.build());
    }



}
