package com.example.a5_weighttracker_cs3600;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class NotifyFragment extends Fragment {

    private static final String PREFS_NAME = "GoalPrefs";
    private static final String KEY_NOTIFICATIONS_ENABLED = "notifications_enabled";

    TextView textNotifyStatus;
    Button btnToggleNotify;

    boolean notificationsEnabled;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_notify, container, false);

        textNotifyStatus = view.findViewById(R.id.textNotifyStatus);
        btnToggleNotify = view.findViewById(R.id.btnToggleNotify);

        // Load saved state
        SharedPreferences prefs = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        notificationsEnabled = prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, false);

        btnToggleNotify.setOnClickListener(v -> {
            notificationsEnabled = !notificationsEnabled; // toggle
            saveNotificationPreference(notificationsEnabled);
            updateUI();
        });

        updateUI();
        return view;
    }

    private void saveNotificationPreference(boolean enabled) {
        SharedPreferences prefs = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(KEY_NOTIFICATIONS_ENABLED, enabled);
        editor.apply();
    }
// updates ui display
    private void updateUI() {
        if (notificationsEnabled) {
            textNotifyStatus.setText("Notifications are ON");
            btnToggleNotify.setText("Disable Notifications");
        } else {
            textNotifyStatus.setText("Notifications are OFF");
            btnToggleNotify.setText("Enable Notifications");
        }
    }
}
