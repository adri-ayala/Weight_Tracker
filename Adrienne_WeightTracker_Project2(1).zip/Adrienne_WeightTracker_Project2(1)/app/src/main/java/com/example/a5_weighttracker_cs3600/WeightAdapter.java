package com.example.a5_weighttracker_cs3600;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    private ArrayList<WeightItem> weights;
    private Context context;
    private DatabaseHelper db;
    private Runnable refreshList;

    public WeightAdapter(Context context, ArrayList<WeightItem> weights, Runnable refreshList) {
        this.context = context;
        this.weights = weights;
        this.refreshList = refreshList;
        this.db = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.weight_item, parent, false);
        return new ViewHolder(view);
    }

    @Override // displays
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightItem item = weights.get(position);

        holder.textDate.setText(item.getDate());
        holder.textWeight.setText(item.getWeight() + " lbs");

        // edit button
        holder.btnEdit.setOnClickListener(v -> showEditDialog(item));

        // delete button
        holder.btnDelete.setOnClickListener(v -> {
            db.deleteWeight(item.getId());
            refreshList.run();
        });
    }
// edits weights
    private void showEditDialog(WeightItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit Weight");

        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_edit_weight, null);
        builder.setView(dialogView);

        EditText editWeightInput = dialogView.findViewById(R.id.editWeightValue);
        editWeightInput.setText(String.valueOf(item.getWeight()));

        builder.setPositiveButton("Save", (dialog, which) -> {
            double newWeight = Double.parseDouble(editWeightInput.getText().toString());
            db.updateWeight(item.getId(), newWeight);
            refreshList.run();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    @Override
    public int getItemCount() {
        return weights.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView textDate, textWeight;
        ImageView btnEdit, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textDate = itemView.findViewById(R.id.textDate);
            textWeight = itemView.findViewById(R.id.textWeight);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
