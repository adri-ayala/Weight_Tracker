package com.example.a5_weighttracker_cs3600;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weightTracker.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

//Creates Tables
    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)");
        db.execSQL("CREATE TABLE weights (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, weight REAL, user_id INTEGER)");
        db.execSQL("CREATE TABLE goal (user_id INTEGER PRIMARY KEY, goal REAL)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS goal"); //
        onCreate(db);
    }


    // Create User
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        long result = db.insert("users", null, values);
        return result != -1;
    }

    // Verify Login
    public int loginUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM users WHERE username=? AND password=?", new String[]{username, password});
        if(cursor.moveToFirst()) {
            return cursor.getInt(0);
        }
        return -1;
    }

    //Insert Weight
    public boolean addWeight(String date, double weight, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("weight", weight);
        values.put("user_id", userId);
        long result = db.insert("weights", null, values);
        return result != -1;
    }

    // Read weights for user
    public Cursor getWeights(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM weights WHERE user_id=?", new String[]{String.valueOf(userId)});
    }

    // Update Weight
    public void updateWeight(int id, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE weights SET weight=? WHERE id=?", new Object[]{weight, id});
    }

    // Delete Weight
    public void deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM weights WHERE id=?", new Object[]{id});
    }

    //Set user goal
    public boolean setGoal(int userId, double goal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user_id", userId);
        cv.put("goal", goal);

        // If user already has a goal, update instead of insert
        int rows = db.update("goal", cv, "user_id=?", new String[]{String.valueOf(userId)});
        if (rows == 0) {
            return db.insert("goal", null, cv) != -1;
        }
        return true;
    }

    public Double getGoal(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT goal FROM goal WHERE user_id=?", new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            return cursor.getDouble(0);
        }
        return null;
    }

}
