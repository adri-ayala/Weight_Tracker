package com.example.a5_weighttracker_cs3600;

import android.database.Cursor;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class GoalFragment extends Fragment {

    EditText editGoal;
    Button btnSaveGoal;
    TextView textCurrentGoal, textDifference;

    DatabaseHelper db;
    int userId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_goal, container, false);

        userId = getActivity().getIntent().getIntExtra("user_id", -1);
        db = new DatabaseHelper(getContext());

        editGoal = view.findViewById(R.id.editGoal);
        btnSaveGoal = view.findViewById(R.id.btnSaveGoal);
        textCurrentGoal = view.findViewById(R.id.textCurrentGoal);
        textDifference = view.findViewById(R.id.textDifference);

        loadGoal();
        loadDifference();

        btnSaveGoal.setOnClickListener(v -> {
            String goalStr = editGoal.getText().toString().trim();
            if (goalStr.isEmpty()) {
                Toast.makeText(getContext(), "Please enter a goal.", Toast.LENGTH_SHORT).show();
                return;
            }

            double goal = Double.parseDouble(goalStr);
            if (db.setGoal(userId, goal)) {
                Toast.makeText(getContext(), "Goal Saved!", Toast.LENGTH_SHORT).show();
                loadGoal();
                loadDifference();
            }
        });

        return view;
    }
// displays current goal
    private void loadGoal() {
        Double goal = db.getGoal(userId);
        if (goal != null) {
            textCurrentGoal.setText("Goal: " + goal + " lbs");
        } else {
            textCurrentGoal.setText("Goal: not set");
        }
    }
// displays differeence between last enetred weight and current goal
    private void loadDifference() {
        Cursor cursor = db.getWeights(userId);
        if (cursor.getCount() > 0) {
            cursor.moveToLast();
            double lastWeight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
            Double goal = db.getGoal(userId);
            if (goal != null) {
                double diff = lastWeight - goal;
                textDifference.setText("Difference from goal: " + String.format("%.1f", diff) + " lbs");
            }
        }
    }
}
